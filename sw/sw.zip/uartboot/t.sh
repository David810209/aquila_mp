export PATH=$PATH:/opt/riscv/bin
export RISCV=/opt/riscv