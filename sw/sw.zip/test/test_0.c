#include <stdio.h>
#define DONE_0 0x4321
#define DONE_1 0x8765

volatile unsigned int *done_0 = (unsigned int *)0x80000000U;
volatile unsigned int *done_1 = (unsigned int *)0x80000004U;
volatile unsigned int *done_2 = (unsigned int *)0x80000008U;
volatile unsigned int *done_3 = (unsigned int *)0x8000000cU;

volatile unsigned int *data_0 = (unsigned int *)0x80000010U;
volatile unsigned int *data_1 = (unsigned int *)0x80000014U;
volatile unsigned int *data_2 = (unsigned int *)0x80000018U;
volatile unsigned int *data_3 = (unsigned int *)0x8000001cU;

volatile unsigned int *init_done = (unsigned int *)0x80000020U;
int main(){
    *init_done = 0;
    *done_0 = 0;
    *done_1 = 0;
    *done_2 = 0;
    *done_3 = 0;
    *init_done = 1;
    *data_0 = 1;
    *done_0 = 1;
    while(*done_0 == 1 && *done_1 == 1 && *done_2 == 1 && *done_3 == 1);
    printf("data_0 = %d\n", *data_0);
    printf("data_1 = %d\n", *data_1);
    printf("data_2 = %d\n", *data_2);
    printf("data_3 = %d\n", *data_3);
    return 0;
}