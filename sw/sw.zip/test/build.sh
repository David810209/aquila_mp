make PROJ=test_0
make PROJ=test_1
make PROJ=test_2
make PROJ=test_3