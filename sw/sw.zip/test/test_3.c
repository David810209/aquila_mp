#include <stdio.h>
#define DONE_0 0x4321
#define DONE_1 0x8765

volatile unsigned int *done_0 = (unsigned int *)0x80000000U;
volatile unsigned int *done_1 = (unsigned int *)0x80000004U;
volatile unsigned int *done_2 = (unsigned int *)0x80000008U;
volatile unsigned int *done_3 = (unsigned int *)0x8000000cU;

volatile unsigned int *data_0 = (unsigned int *)0x80000010U;
volatile unsigned int *data_1 = (unsigned int *)0x80000014U;
volatile unsigned int *data_2 = (unsigned int *)0x80000018U;
volatile unsigned int *data_3 = (unsigned int *)0x8000001cU;

volatile unsigned int *init_done = (unsigned int *)0x80000020U;
int main(){
    while(*init_done != 1);
    *data_3= 3;
    *done_3 = 1;
    return 0;
}